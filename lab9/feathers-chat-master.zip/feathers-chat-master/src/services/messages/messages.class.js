const { Service } = require('feathers-nedb');

exports.Messages = class Messages extends Service {
  
};
